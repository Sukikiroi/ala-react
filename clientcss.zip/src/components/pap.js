import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Firstpage from './Firstpage'
import MenuAnt from './MenuAnt'
import Expan from './expan'
const useStyles = makeStyles(theme => ({
  root: {
    padding: theme.spacing(3, 2),
  },
}));

export default function PaperSheet() {
  const classes = useStyles();

  return (
    <div>
	<Paper className={classes.root}>
        <Expan/>
      </Paper>
      <Paper className={classes.root}>
		<Firstpage/>
		<MenuAnt/>
      </Paper>
    </div>
  );
}