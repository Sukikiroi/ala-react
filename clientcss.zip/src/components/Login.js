import React from 'react';
import Stepss from './steprss'

export default function firstpage() {

  return (
   <Stepss/>
  );
}
