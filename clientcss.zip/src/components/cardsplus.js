import React from 'react';

import Cards from './cards'

export default function RecipeReviewCard() {

  return (
 <div>
<Cards/>
<Cards/>
</div> 
  );
}
